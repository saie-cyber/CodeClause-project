<samp>
  
# [MusicPlayer](https://kalebujordan.dev/make-your-own-music-player-in-python/)
  
Simple Basic Player implemented in Python using Tkinter &amp; Pygame Library
![](musicPlayer.png?raw=true), To read full artilce guiding you step by step on how to build music player please have a visit at [kalebujordan.dev](https://kalebujordan.dev/make-your-own-music-player-in-python/)
  
  Issues 
  ------
  If you will encounter any issue while trying to run this script, please raise one so as we can fix it as possible 
  
  Credits
  --------
  1. All the credits to [kalebu](https://github.com/Kalebu/)
