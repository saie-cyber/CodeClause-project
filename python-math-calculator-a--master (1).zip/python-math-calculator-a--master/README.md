# Python Math Calculator

## Maintainers

This math calculator is maintained by our organisation :smile:

## Software

In order to run this software, you will need:

1. The Software

2. The Python System

3. A Python Code Editor

P.S. We suggest that you use PyCharm on a Laptop and Pythonista on mobile.

## How does this repository run?

We run on a contributing basis. Inside the Main Branch, you can help to update our Version updates. After we have completed with the Version Updates, we will release them in the Releases section.

## Status

[![CodeFactor](https://www.codefactor.io/repository/github/pythonmathcalculator/python-math-calculator/badge)](https://www.codefactor.io/repository/github/pythonmathcalculator/python-math-calculator)
