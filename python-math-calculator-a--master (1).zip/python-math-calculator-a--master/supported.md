# Supported Versions

You can find whether we still support the version you have downloaded here!

| Version Number  | Supported? |
| ------------- | ------------- |
| Version 1.0  | Supported |
| Version 2.0  | Supported |
| Version 3.0  | Supported |

Do note that we will not role out support updates occasionaly. We will only create supoprt ideas when a issue or pull request has been set up by a member of the community.
